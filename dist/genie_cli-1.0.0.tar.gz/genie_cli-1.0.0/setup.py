# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['genie_cli']

package_data = \
{'': ['*']}

install_requires = \
['black>=22.12.0,<23.0.0',
 'isort>=5.11.4,<6.0.0',
 'pytz>=2022.7,<2023.0',
 'requests>=2.28.1,<3.0.0',
 'typer[all]>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['genie-cli = genie_cli.main:app']}

setup_kwargs = {
    'name': 'genie-cli',
    'version': '1.0.0',
    'description': 'A CLI for interacting with EnvGenie',
    'long_description': '# genie-cli\nA simple to use CLI for interacting with EnvGenie, since cURL is not so convenient.\n\n```\n> genie-cli --help\n\n Usage: genie-cli [OPTIONS] COMMAND [ARGS]...\n\n╭─ Options ────────────────────────────────────────────────────────────────────╮\n│ --install-completion          Install completion for the current shell.      │\n│ --show-completion             Show completion for the current shell, to copy │\n│                               it or customize the installation.              │\n│ --help                        Show this message and exit.                    │\n╰──────────────────────────────────────────────────────────────────────────────╯\n╭─ Commands ───────────────────────────────────────────────────────────────────╮\n│ add-env                                                                      │\n│ delete-env                                                                   │\n│ display-env                                                                  │\n│ list-apps                                                                    │\n│ list-envs                                                                    │\n│ login                                                                        │\n╰──────────────────────────────────────────────────────────────────────────────╯\n\n```',
    'author': 'Parikshit Misra',
    'author_email': '98179308+parikshit-parspec@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
